import React from 'react';
import './App.css';
import Divider from "./Divider";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p></p>
        <img src="game_board_small.png" />
        <p></p>
      </header>
       <Divider />
    </div>
  );
}

export default App;
